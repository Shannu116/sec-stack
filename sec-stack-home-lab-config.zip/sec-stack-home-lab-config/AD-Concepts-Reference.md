# AD Concepts Reference — Distribution Groups, File Share Resource Groups, NTFS/Sharing Security

**Domain:** corp.internal
**Purpose:** Explains three AD/file-server concepts relevant to the lab, notes what already exists vs. what's new, and why each is needed in a real company.

---

## 1. Distribution Groups

### Status: NOT yet created — new concept, needs building

### What it is
A Distribution Group is a **mail-enabled** group with **no security function at all**. It cannot be granted NTFS permissions, cannot be added to an ACL, and cannot be nested into a Domain Local group for resource access. Its only job is: "when someone emails this address, deliver the message to everyone inside it."

This is a common point of confusion — Security groups *can* also receive email if mail-enabled in Exchange/M365, but Distribution groups can **never** be used for permissions. They are two fundamentally different object types in AD, chosen at creation time via the "Group Type" field (Security vs. Distribution).

### Why a real company needs them
- **`all-employees@corp.internal`** — company-wide announcements, without accidentally exposing file-share or app access to everyone who receives the email.
- **`hr-announcements@corp.internal`** — HR broadcasts benefits/policy updates to the whole company, without HR needing security rights over anyone.
- **Separation of concerns** — security groups change carefully (they gate access to real resources); distribution groups can be edited freely by department admins without a security review, since email membership carries no access risk.

### Proposed Distribution Groups for corp.internal

| Group Name | Purpose | Members |
|---|---|---|
| `DG-AllEmployees` | Company-wide announcements | All 15 department Global groups nested inside |
| `DG-Region-USA` | USA-only announcements | USA-IT, USA-Accounting, USA-HR, USA-Sales, USA-Management |
| `DG-Region-Europe` | Europe-only announcements | Europe-IT, Europe-Accounting, Europe-HR, Europe-Sales, Europe-Management |
| `DG-Region-India` | India-only announcements | India-IT, India-Accounting, India-HR, India-Sales, India-Management |
| `DG-Dept-HR-Global` | Cross-region HR communications | USA-HR, Europe-HR, India-HR |
| `DG-Dept-Sales-Global` | Cross-region Sales communications | USA-Sales, Europe-Sales, India-Sales |
| `DG-Management-Announcements` | Leadership-only distribution | USA-Management, Europe-Management, India-Management |

---

## 2. Resource Groups for File Shares (Domain Local Scope)

### Status: ALREADY EXISTS — built in the earlier reference workbook as `DL-FS-*` groups

### What it is
A Domain Local security group whose entire purpose is holding **NTFS/share permissions to one specific resource** — never used for email, never used for logging in, never assigned directly to a user. Global groups (which represent "who someone is") get nested inside it; the Domain Local group is what actually appears on the resource's Access Control List (ACL).

This is the "DL" step in the AGDLP model covered in the earlier workbook (`Overview` tab).

### Already created (for reference — see `corp_internal_AD_reference.xlsx`, tab "Domain Local Groups (Resources)")
- `DL-FS-HR-Confidential` → HR share
- `DL-FS-Accounting-RW` → Finance share
- `DL-FS-Sales-RW` → Sales share
- `DL-FS-Management-Exec` → Executive share
- `DL-FS-AllStaff-Public` → Company-wide public share

### Why a real company needs them
- **Permissions attach to the group, not the user.** When someone joins HR, they're added to `India-HR` (Global) once — they automatically inherit file-share access because `India-HR` is already nested inside `DL-FS-HR-Confidential`. No one has to remember to touch the file server's ACL for every new hire.
- **Auditing is trivial.** "Who can access the HR share?" is answered by listing one group's members, not by opening the folder's security tab and cross-referencing dozens of individual user entries.
- **This is exactly what auditors/pentesters check.** A folder with individual *user* accounts directly on its ACL (instead of a Domain Local group) is a classic finding in a security review — it means access wasn't reviewed as a policy, it was granted ad hoc.

---

## 3. Manual Folder Security (NTFS & Sharing Guide)

### Status: NOT yet created — no walkthrough exists yet, added here

### What it is
Two **separate, stacked** permission layers exist on any Windows file share, and real environments configure them differently on purpose:

| Layer | Where it's set | What it controls | Typical real-world setting |
|---|---|---|---|
| **Share permissions** | Right-click folder → Properties → Sharing → Advanced Sharing → Permissions | Access when connecting over the network (`\\server\share`) | Usually left loose: `Authenticated Users` = Change |
| **NTFS permissions** | Right-click folder → Properties → Security tab | Access at the filesystem level, applies whether local or network | The real gatekeeper: specific `DL-FS-*` groups with exact rights |

When both layers apply, Windows enforces the **more restrictive** of the two (their intersection). This is why real companies leave Share permissions wide open and do all the actual access control at the NTFS layer — it's one place to manage, and it still applies even if someone RDPs directly onto the file server instead of connecting over the network.

### Why a real company needs this documented
- **Prevents the #1 file-server misconfiguration:** setting restrictive Share permissions AND restrictive NTFS permissions independently, then wondering why access is more locked-down than intended (the intersection silently wins).
- **Onboarding new sysadmins/helpdesk staff** — this trips up nearly everyone the first time they configure a share, and is a very common interview question ("what's the difference between share and NTFS permissions, and which one wins?").
- **Matches the AGDLP model** — the DL groups from section 2 above are *useless* until they're actually applied to a folder's NTFS ACL. This is the missing final step that makes the whole group structure functional rather than theoretical.

The full step-by-step walkthrough for actually configuring this is in the companion file: `AD-Stepbystep-Setup-Guide.md`.

---

## 4. Group Policy Objects (GPO)

### Status: NOT yet created — required for Splunk log quality, added here

### What it is
Everything in sections 1–3 above (Global groups, Domain Local groups, Distribution groups) answers **"who is allowed to access what?"** A GPO answers a completely different question: **"how should this computer or user behave?"**

| | Security Groups (Global/DL/Universal) | GPO |
|---|---|---|
| Answers | Who can access what | How a computer/user should behave |
| Controls | Permissions on resources (files, apps, delegated rights) | Settings applied to computers/users (audit policy, password rules, restrictions) |
| Mechanism | Add the group to a resource's ACL | Link the GPO to an OU, it pushes settings automatically |
| Example | `DL-FS-HR-Confidential` grants Modify on one folder | A GPO linked to `OU=Computers,OU=USA` enforces lockout policy on every machine there |

**Groups and GPOs are not separate systems — they work together.** A GPO's "Restricted Groups" setting can push one of your Domain Local groups (e.g. `DL-ServerAdmins-USA`) into the local Administrators group on every server in an OU automatically. GPO "Security Filtering" can scope a policy to apply only to members of a specific group. The group is the "who," the GPO is the delivery mechanism.

### Why this lab specifically needs it
**A default Windows Server install logs almost nothing useful to the Security event log.** The specific event IDs a SOC analyst builds detections around — 4624/4625 (logon/failed logon), 4688 (process creation, with full command line), 4720 (user created), 4732 (added to a security group) — require **Advanced Audit Policy** to be explicitly enabled. Without it, your `windows_security` Splunk index will be sparse or empty regardless of how well the log pipeline itself is configured. This is the single biggest lever for "getting perfect logs" into Splunk — bigger than any Splunk-side tuning.

### GPOs needed for this lab

| GPO | Linked to | Purpose |
|---|---|---|
| **Advanced Audit Policy** | Domain root (or per-OU) | Enables logon events, process creation, account management, object access logging — the most important one for SOC visibility |
| **Command Line Process Auditing** | Domain root | Extends event 4688 to include the full command line — critical for seeing exactly what a PowerShell/cmd command did |
| **Password Policy** | Domain root | Enforces complexity, length, lockout threshold consistently (replaces doing this manually per-user, which is what caused the earlier `alex@20#26IT` rejection) |
| **Restricted Groups** | `OU=Computers,OU=USA` / `Europe` / `India` | Pushes `DL-ServerAdmins-<Region>` into the local Administrators group on every server in that OU automatically — this is what makes those Domain Local groups from Section 2 actually functional instead of theoretical |
| **Sysmon deployment (optional)** | `OU=Computers` | Pushes the Sysmon binary + config via startup script, so newly joined machines auto-configure without manual install |

Full step-by-step configuration for each is in `AD-Stepbystep-Setup-Guide.md`, Step 8.

---

## 5. PowerShell Logging (Module, Script Block, Transcription)

### Status: NOT yet created — closes a real gap left by Section 4's Advanced Audit Policy

### What it is
Section 4's **Command Line Process Auditing** (event 4688) only captures the moment a PowerShell process *starts* — the initial command line used to launch it. It does **not** capture what happens after that: individual commands typed inside an already-open interactive session, or the actual content of a script that runs, especially if that content is built dynamically or obfuscated. If someone opens PowerShell and runs twenty commands in a row, 4688 shows exactly one process-creation event — not twenty.

Three separate GPO settings close this gap, each capturing something different:

| Setting | What it captures | Event ID / Location |
|---|---|---|
| **Module Logging** | Every pipeline execution — which cmdlets ran, with parameters | Event 4103, `Microsoft-Windows-PowerShell/Operational` log |
| **Script Block Logging** | The actual code/script block text, even if built dynamically or partially obfuscated — this is the one real SOC tooling leans on most | Event 4104 (4105/4106 for flagged suspicious content), same log |
| **Transcription** | A full plain-text transcript of input/output per session, written to disk | Plain text files, NOT the event log — needs a separate file-monitor input, not `WinEventLog://` |

### Why this lab specifically needs it
This is the distinction that matters for "getting perfect logs" — 4688 *looks* like it covers PowerShell activity because it's the process that shows up, but it's covering the process, not the commands. Without Module/Script Block Logging, a huge category of attacker activity (living-off-the-land PowerShell abuse, encoded/obfuscated one-liners, fileless malware) would be invisible in Splunk even with Section 4 fully configured. This is also a genuinely different log channel (`Microsoft-Windows-PowerShell/Operational`, not `Security`), so it needs its own Splunk index/sourcetype and its own `inputs.conf` stanza — it won't ride along with anything already configured.

### Do you actually need Transcription specifically?
Script Block Logging (4104) alone answers most SOC detection questions — "did someone run a suspicious cmdlet," "was there an encoded command," "what did this script do." Transcription adds two things on top: (1) console output/interaction, not just the commands typed, and (2) an independent flat-file copy that doesn't depend on the event-log pipeline at all — useful if that pipeline is ever tampered with. For a lab focused on Splunk detections, prioritize Script Block Logging first; treat Transcription as a defense-in-depth add-on once the rest is solid.

### Where transcripts should be stored
Left at its default, each user's transcripts land scattered in their own profile (`%USERPROFILE%\Documents\`) and can be freely deleted by that user — bad for evidence integrity. Point the GPO's "Transcript output directory" field at a central folder instead (`C:\PSTranscripts`), then lock its NTFS permissions so accounts can append new transcripts but can't read or delete existing ones (`(AD,WD)` — append/write data, no delete, no read).

Full step-by-step configuration (GPO settings, ACL commands, Splunk `inputs.conf`/`indexes.conf` additions) is in `AD-Stepbystep-Setup-Guide.md`, Step 8f.
