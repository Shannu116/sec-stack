# Step-by-Step Setup Guide — corp.internal AD Lab

**Purpose:** Exact build order and one worked example of each object type, so you can replicate the pattern for the remaining 45 users / 15 Global groups / 16 Domain Local groups / 4 Universal groups / 7 Distribution groups / folder security / GPOs.

## Build Order (do it in this sequence — each step depends on the one before it)

1. OU structure (already done)
2. Global groups (department × region)
3. Users (created + added to their Global group)
4. Domain Local resource groups (with Global groups nested inside)
5. Distribution groups
6. Actual folders on the file server + Share permissions + NTFS permissions (using the Domain Local groups from step 4)
7. Verification / testing
8. GPOs (Advanced Audit Policy, Password Policy, Restricted Groups, Command Line Auditing, PowerShell Logging)

Building in this order means every group you create already has something valid to nest or reference — you're never creating an empty group and coming back to it later.

---

## Step 1: Create a Global Group (department × region) --> Completed

**Example: `USA-IT`**

1. Open **Active Directory Users and Computers** (ADUC).
2. Navigate to `OU=Users,OU=USA,DC=corp,DC=internal`.
3. Right-click the OU → **New → Group**.
4. Fill in:
   - **Group name:** `USA-IT`
   - **Group scope:** `Global`
   - **Group type:** `Security`
5. Click **OK**.
6. (Optional but recommended) Right-click the new group → **Properties** → **General** tab → add a Description: `All IT personnel in the USA region`.

**Repeat this 15 times** — once per region × department combination (USA/Europe/India × IT/Accounting/HR/Sales/Management). Reference: `corp_internal_AD_reference.xlsx`, tab "Global Groups (Dept)".

---

## Step 2: Create a User and Add to Their Global Group --> Completed

**Example: Alex Miller, IT Support Technician, USA**

1. In ADUC, right-click `OU=Users,OU=USA,DC=corp,DC=internal` → **New → User**.
2. Fill in:
   - **First name:** `Alex`
   - **Last name:** `Miller`
   - **Full name:** `Alex Miller` (auto-fills)
   - **User logon name (UPN):** `us_it_alex` → will show as `us_it_alex@corp.internal`
3. Click **Next**.
4. Set the password (from the reference workbook: `P@ssw0rd2026!`), check:
   - ☑ **User must change password at next logon**
5. Click **Next → Finish**.
6. Right-click the new user → **Properties**:
   - **Organization tab:** Job Title = `IT Support Technician`, Department = `IT`, Company = `corp.internal`
   - **General tab:** Office = `USA`
7. Add to group: right-click the user → **Add to a group…** → type `USA-IT` → **OK**.

**Repeat for all 45 users** using the full detail table in `corp_internal_AD_reference.xlsx`, tab "Users (45)".

---

## Step 3: Create a Domain Local Resource Group and Nest Global Groups Inside It

**Example: `DL-FS-HR-Confidential`**

1. Right-click `OU=Groups,DC=corp,DC=internal` (create this OU first if it doesn't exist yet) → **New → Group**.
2. Fill in:
   - **Group name:** `DL-FS-HR-Confidential`
   - **Group scope:** `Domain Local`
   - **Group type:** `Security`
3. Click **OK**.
4. Right-click `DL-FS-HR-Confidential` → **Properties → Members tab → Add**.
5. Type all three regional HR groups, separated by semicolons: `USA-HR; Europe-HR; India-HR` → **OK**.
6. Verify: the Members tab should now list all three Global groups (not individual users — that's the point).

**Repeat for the remaining 15 Domain Local groups** listed in `corp_internal_AD_reference.xlsx`, tab "Domain Local Groups (Resources)".

> **Note:** that tab has two separate columns worth reading carefully — **"Group Created In (OU Path)"** is always `OU=Groups,DC=corp,DC=internal` (that's where you create the group object itself, same as the example above), while **"Applies To (Resource Scope)"** tells you what the group actually grants access _to_ (a file share, a GPO object, an OU of servers, etc.) — that's a different thing and comes into play later in Steps 6 and 8, not at creation time.

---

## Step 4: Create a Universal Security Group (company-wide, not email)

**Example: `UG-AllEmployees-Global`**

Don't confuse this with Distribution groups in Step 5 below — these are **Security** type, Universal **scope**, used for company-wide groupings that need to work across domains (see `AD-Concepts-Reference.md` for why Universal scope matters). In this single-domain lab they function like Global groups, but modeling them separately is worth the practice.

1. Right-click `OU=Groups,DC=corp,DC=internal` → **New → Group**.
2. Fill in:
   - **Group name:** `UG-AllEmployees-Global`
   - **Group scope:** `Universal`
   - **Group type:** `Security` ← different from Step 5's Distribution groups, easy to mix up
3. Click **OK**.
4. Add members: Properties → Members → Add → paste in all 15 department Global groups.

**Repeat for the remaining 3 Universal groups** listed in `corp_internal_AD_reference.xlsx`, tab "Universal Groups" (`UG-ExecutiveLeadership`, `UG-ITAdmins-Global`, `UG-Contractors-External`).

---

## Step 5: Create a Distribution Group

**Example: `DG-AllEmployees`**

1. Right-click `OU=Groups,DC=corp,DC=internal` → **New → Group**.
2. Fill in:
   - **Group name:** `DG-AllEmployees`
   - **Group scope:** `Universal` (Universal is the standard choice for company-wide distribution lists — it works even if the domain later expands)
   - **Group type:** `Distribution` ← this is the setting that matters most; it's easy to leave on the "Security" default by mistake
3. Click **OK**.
4. Add members the same way as before: Properties → Members → Add → paste in all 15 department Global groups.

**Repeat for the remaining 6 Distribution groups** listed in `AD-Concepts-Reference.md`.

---

## Step 6: Create the Folder, Share It, and Set NTFS Permissions

**Example: HR Confidential share on the file server**

### 6a — Create the folder

1. On the file server, create the folder: `D:\Shares\HR`

### 6b — Share it (loose permissions here on purpose)

1. Right-click the folder → **Properties → Sharing tab → Advanced Sharing**.
2. Check **Share this folder**, Share name: `HR`.
3. Click **Permissions**.
4. Remove `Everyone` if present. Add `Authenticated Users`, grant **Change**. Click **OK**.

_(This is intentionally not the real gatekeeper — NTFS below is.)_

### 6c — Set NTFS permissions (the real gatekeeper)

1. Still in folder Properties → **Security tab → Advanced**.
2. Click **Disable inheritance** → **Convert inherited permissions into explicit permissions on this object** (so you start from a clean, known state).
3. Remove the generic `Users` or `Authenticated Users` entry if present.
4. Click **Add** → **Select a principal** → type `DL-FS-HR-Confidential` → **OK**.
5. Set permission: **Modify** (this covers read/write/delete without granting full NTFS ownership rights).
6. Also ensure `SYSTEM` = Full Control and `Domain Admins` = Full Control remain present (standard baseline — don't remove these).
7. Click **OK → Apply → OK**.

### 6d — Result

Only members of `DL-FS-HR-Confidential` (which currently means `USA-HR`, `Europe-HR`, `India-HR` — i.e., every HR employee in the company, and no one else) can access `\\fileserver\HR`.

**Repeat 6a–6c for each of the 5 department shares** (`Accounting`, `Sales`, `Executive`, `Public`), using the matching `DL-FS-*` group each time.

---

## Step 7: Verify

1. Log on (or `runas /user:corp\us_it_alex cmd`) as a test user, e.g. `us_it_alex` (IT — should NOT have HR access).
2. Try to browse `\\fileserver\HR` — should be **denied**.
3. Log on as `in_hr_kavya` (HR) — should browse `\\fileserver\HR` successfully and be able to create/edit a file (Modify right).
4. Document the result — this pairs with your chain-of-custody log as evidence the access model actually works as designed, not just as configured.

---

## Step 8: Configure GPOs (required for clean Splunk logs)

This is the step that determines whether your `windows_security` Splunk index actually fills up with useful events. Do this on the Domain Controller via **Group Policy Management Console** (`gpmc.msc`).

### 8a — Advanced Audit Policy (the most important one)

1. Open **Group Policy Management** → right-click `corp.internal` (domain root) → **Create a GPO in this domain, and Link it here**.
2. Name it `GPO-Advanced-Audit-Policy` → OK.
3. Right-click it → **Edit**.
4. Navigate to: `Computer Configuration → Policies → Windows Settings → Security Settings → Advanced Audit Policy Configuration → Audit Policies`.
5. Enable **Success and Failure** for these subcategories (the ones that actually matter for a SOC lab):
   - **Account Logon** → Audit Kerberos Authentication Service, Audit Credential Validation
   - **Account Management** → Audit Security Group Management, Audit User Account Management
   - **Detailed Tracking** → Audit Process Creation (this is what enables event 4688)
   - **Logon/Logoff** → Audit Logon, Audit Logoff, Audit Special Logon
   - **Policy Change** → Audit Authentication Policy Change
   - **System** → Audit Security State Change
6. Close the editor. Run `gpupdate /force` on the DC, or wait for the default refresh interval.

### 8b — Command Line Process Auditing (extends 4688 with full command line)

1. Same GPO (or a new one) → **Edit**.
2. Navigate to: `Computer Configuration → Policies → Administrative Templates → System → Audit Process Creation`.
3. Enable **"Include command line in process creation events"**.

### 8c — Password Policy

1. Create GPO `GPO-Password-Policy`, link to domain root (or edit the Default Domain Policy directly, which is the standard location for this one).
2. Navigate to: `Computer Configuration → Policies → Windows Settings → Security Settings → Account Policies → Password Policy`.
3. Set: Minimum password length = 12, Enforce password history = 5, Maximum password age = 90 days, Account lockout threshold = 5 invalid attempts.

### 8d — Restricted Groups (makes your Domain Local server-admin groups functional)

**Example: pushing `DL-ServerAdmins-USA` into the local Administrators group on every USA server**

1. Create GPO `GPO-RestrictedGroups-USA`, link it to `OU=Servers,OU=USA,DC=corp,DC=internal`.
2. Edit → `Computer Configuration → Policies → Windows Settings → Security Settings → Restricted Groups`.
3. Right-click → **Add Group** → type `Administrators` (the local group being controlled).
4. In "Members of this group," add `DL-ServerAdmins-USA`.
5. Repeat with separate GPOs for `Europe` and `India` server OUs using their matching group.

### 8e — Verify the audit policy actually took effect

On the DC, run:

```powershell
gpresult /r
auditpol /get /category:*
```

### 8f — PowerShell Logging (Module, Script Block, Transcription)

This is a **different GPO area** from 8a-8d (Administrative Templates, not Security Settings) and closes a real gap: event 4688 only shows that a PowerShell process *started*, not what commands ran inside it. Do all three sub-settings in the same GPO (or a new one, e.g. `GPO-PowerShell-Logging`), linked to domain root.

**Module Logging:**
1. Edit the GPO → `Computer Configuration → Policies → Administrative Templates → Windows Components → Windows PowerShell → Turn on Module Logging`.
2. Set to **Enabled**, Module Names = `*`.

**Script Block Logging (the important one):**
1. Same location → `Turn on PowerShell Script Block Logging`.
2. Set to **Enabled**.

**Transcription (optional, defense-in-depth):**
1. Same location → `Turn on PowerShell Transcription`.
2. Set to **Enabled**, check **Include invocation headers**.
3. Set **Transcript output directory** to `C:\PSTranscripts` — don't leave this blank (default scatters transcripts into each user's own profile, deletable by that user).
4. Create and lock down the folder on the target machine(s) *before* transcripts start writing:
```powershell
New-Item -Path "C:\PSTranscripts" -ItemType Directory
icacls "C:\PSTranscripts" /inheritance:r
icacls "C:\PSTranscripts" /grant "SYSTEM:(OI)(CI)F"
icacls "C:\PSTranscripts" /grant "Domain Admins:(OI)(CI)F"
icacls "C:\PSTranscripts" /grant "Authenticated Users:(OI)(CI)(AD,WD)"
```
`(AD,WD)` = append/write data only — accounts can create new transcripts but can't read or delete existing ones.

5. `gpupdate /force`.

### 8g — Add the new log source to Splunk

This is a **different log channel** (`Microsoft-Windows-PowerShell/Operational`) than Security, plus a **file-based** source (transcripts) — neither rides along with your existing `inputs.conf`. Add both:

On the Universal Forwarder, append to `inputs.conf`:
```
[WinEventLog://Microsoft-Windows-PowerShell/Operational]
disabled = false
index = windows_powershell
sourcetype = WinEventLog:PowerShell
renderXml = false

[monitor://C:\PSTranscripts\*.txt]
disabled = false
index = windows_powershell
sourcetype = powershell:transcript
```

On the indexer, add a new stanza to `indexes.conf`:
```
[windows_powershell]
homePath   = $SPLUNK_DB/windows_powershell/db
coldPath   = $SPLUNK_DB/windows_powershell/colddb
thawedPath = $SPLUNK_DB/windows_powershell/thaweddb
```

### 8h — Verify

```powershell
Get-WinEvent -LogName "Microsoft-Windows-PowerShell/Operational" -MaxEvents 5
Get-ChildItem C:\PSTranscripts
```
Run a test PowerShell command first if either comes back empty. Then in Splunk: `index=windows_powershell | head 5` should show both event-log entries (4103/4104) and transcript file content, distinguished by `sourcetype`.
